<?php

namespace app\admin\model;

use think\Model;

class CustomformsModel extends Model
{ 
    protected $table = "admin_custom_forms";
}
