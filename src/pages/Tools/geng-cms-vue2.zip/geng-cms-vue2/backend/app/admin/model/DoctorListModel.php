<?php

namespace app\admin\model;

use think\Model;

class DoctorListModel extends Model
{ 
    protected $table = "doctor_user_info";
}
