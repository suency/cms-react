<?php

namespace app\admin\model;

use think\Model;

class RolesModel extends Model
{ 
    protected $table = "admin_roles";
}
