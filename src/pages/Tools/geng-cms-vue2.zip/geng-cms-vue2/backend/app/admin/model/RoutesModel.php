<?php

namespace app\admin\model;

use think\Model;

class RoutesModel extends Model
{ 
    protected $table = "admin_menu";
}
