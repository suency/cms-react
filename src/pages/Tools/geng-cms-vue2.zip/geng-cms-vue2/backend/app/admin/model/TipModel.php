<?php

namespace app\admin\model;

use think\Model;

class TipModel extends Model
{ 
    protected $table = "admin_tip";
}
