<?php

namespace app\admin\model;

use think\Model;

class TipdataModel extends Model
{ 
    protected $table = "admin_tip_data";
}
