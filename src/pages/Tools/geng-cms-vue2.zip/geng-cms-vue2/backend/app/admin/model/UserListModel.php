<?php

namespace app\admin\model;

use think\Model;

class UserListModel extends Model
{ 
    protected $table = "wx_user_info";
}
