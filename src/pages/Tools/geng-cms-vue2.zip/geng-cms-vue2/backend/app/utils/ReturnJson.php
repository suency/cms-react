<?php
namespace app\utils;

class ReturnJson{
    public $json;
    public function __construct($data,$status="ok")
    {
        $this->json = ["code"=>20000,"data"=>$data, "status"=>$status];
    }
}