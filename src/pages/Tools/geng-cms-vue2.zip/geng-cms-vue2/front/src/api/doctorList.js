import request from '@/utils/request'

export function getDoctorList() {
  return request({
    url: 'admin/doctorList/getDoctorList',
    method: 'get'
  })
}
