import request from '@/utils/request'

export function get_group_info(data) {
  return request({
    url: 'admin/groupInfo/get_group_info',
    method: 'post',
    data
  })
}

export function update_group_info(data) {
  return request({
    url: 'admin/groupInfo/update_group_info',
    method: 'post',
    data
  })
}

export function add_group_info(data) {
  return request({
    url: 'admin/groupInfo/add_group_info',
    method: 'post',
    data
  })
}

export function delete_group_info(data) {
  return request({
    url: 'admin/groupInfo/delete_group_info',
    method: 'post',
    data
  })
}
