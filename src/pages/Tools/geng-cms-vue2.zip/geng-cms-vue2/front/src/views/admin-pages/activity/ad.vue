<template>
  <div class="app-container">
    提现管理
  </div>
</template>

<script>
// import { getDoctorList } from '@/api/doctorList'

export default {
  data() {
    return {
    }
  },
  mounted: function() {
    this.refresh()
  },
  methods: {
    refresh() {
    }
  }
}
</script>

<style scoped>

</style>
