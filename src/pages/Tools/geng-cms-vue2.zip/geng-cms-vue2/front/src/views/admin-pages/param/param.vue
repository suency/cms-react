<template>
  <div class="app-container">
    <el-table :data="tableData" class="tip" border fit highlight-current-row style="width: 100%">
      <el-table-column v-for="(item, key) in displayProps" :key="key" :label="item" width="150">
        <template slot-scope="scope">
          <span>{{ scope.row[key] }}</span>
        </template>
      </el-table-column>

      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button size="mini" type="primary" @click="modify(scope.row.id)">修改</el-button>
          <el-button size="mini" type="danger" @click="deleteDong(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      style="margin-top: 20px"
      background
      :current-page="query.currentPage"
      :page-sizes="[10, 20, 50, 100, 200]"
      :page-size="query.pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total"
      @size-change="pageSizeChange"
      @current-change="pageChange"
    />
    <!-- 弹出框 -->
    <el-dialog title="修改内容" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item v-for="(item, key) in form" :key="key" :label="form[key].name" :label-width="formLabelWidth">
          <el-input v-model="form[key].value" autocomplete="off" :disabled="key=='id'" />
        </el-form-item>
      </el-form>

      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="confirm">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog
      title="提示"
      :visible.sync="dialogVisibleDelete"
      width="30%"
    >
      <span>确定要删除当前动态吗？id:{{ deleteId }}</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisibleDelete = false">取 消</el-button>
        <el-button type="primary" @click="confirmDelete">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { getConsume } from '@/api/money'
import _ from 'underscore'

export default {
  filters: {
    topicFilter(e) {
      return _.pluck(e, 'topic').toString()
    }
  },
  data() {
    return {
      displayProps: {
        id: 'id',
        consume_amount: '讨论标题',
        create_date: '简介',
        state: '状态'
      },
      dialogFormVisible: false,
      dialogVisibleDelete: false,
      tableData: [
      ],
      form: {
      },
      formLabelWidth: 'auto',
      total: 0,
      query: {
        pageSize: 10,
        currentPage: 1
      },
      deleteId: ''
    }
  },
  mounted: function() {
    this.refresh()
  },
  methods: {
    viewMore(index) {

    },
    pageSizeChange(e) {
      this.query.pageSize = e
      this.refresh()
    },
    pageChange(e) {
      this.query.currentPage = e
      this.refresh()
    },
    deleteDong(id) {
      this.dialogVisibleDelete = true
      this.deleteId = id
    },
    refresh() {
      var that = this
      getConsume(that.query).then(res => {
        that.tableData = res.data.data
        that.total = res.data.total
        // console.log(res)
      })
    },
    modify(id) {
      const that = this
      this.dialogFormVisible = true
      this.form = _.find(that.tableData, item => {
        return item.id === id
      })
      const obj = {}
      for (const iterator in that.displayProps) {
        obj[iterator] = {
          value: that.form[iterator],
          name: that.displayProps[iterator]
        }
      }
      this.form = obj
      console.log(obj)
    },
    confirmDelete() {

    },
    confirm() {
      /* const that = this
      updateCase(this.form).then(res => {
        if (res.code === 20000) {
          this.$message(res.data.msg)
          that.dialogFormVisible = false
          that.refresh()
        }
      }) */
    }
  }
}
</script>

<style scoped>

</style>
